// Local orchestration only: the public reproduction contract is examples/benchmark_grid/README.md.
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const root = process.cwd();
const output = path.join(root, 'target', 'grid-baseline-2026-11-02');
fs.mkdirSync(output);
const exe = path.join(root, 'target', 'release', 'examples', 'benchmark_grid.exe');
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const manifest = {
  schema: 1, source: cp.execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8',windowsHide:true}).trim(),
  sourceStatus: cp.execFileSync('git',['status','--porcelain'],{encoding:'utf8',windowsHide:true}).trim(),
  binarySha256: sha(exe), lockSha256: sha('Cargo.lock'), fontSha256: sha('crates/flui-painting/assets/fonts/Roboto-Regular.ttf'),
  rustc: cp.execFileSync('rustc',['-Vv'],{encoding:'utf8',windowsHide:true}),
  build: 'CARGO_INCREMENTAL=0 cargo heli build --locked --release -p flui --example benchmark_grid --no-default-features',
  profile: {optLevel:3,lto:'thin',codegenUnits:1,strip:'debuginfo',incremental:false},
  machine: {os:'Windows 11 Pro 10.0.26300 build 26300',cpu:'Intel Core i9-13900K',cores:24,logicalProcessors:32,ramBytes:68406284288,power:'Balanced',affinity:'OS default; no pin',gpuInstalled:[{name:'Intel UHD Graphics 770',driver:'32.0.101.7088'},{name:'NVIDIA GeForce RTX 3070 Ti',driver:'32.0.15.6094'}]},
  gpu: {requestedBackend:'dx12',actualAdapter:'UNAVAILABLE: not exposed by HeadlessRenderer',purpose:'separate correctness captures only'},
  statistics: {primary:'median of 5 process p50 wall times',aaSpreadLimit:0.05,practicalImprovement:0.10,percentile:'nearest rank',outliers:'all retained',ordering:'interleaved by repeat, reversed on even repeats'},
  startUtc: new Date().toISOString(), runs: []
};
if(manifest.sourceStatus) throw Error('baseline requires a clean checkout');
function run(args) {
  return new Promise((resolve,reject)=>{
    const child=cp.spawn(exe,args,{cwd:root,windowsHide:true,env:{...process.env,WGPU_BACKEND:'dx12'}});
    let stdout='',stderr='';
    child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
    child.on('error',reject);child.on('close',code=>resolve({code,stdout,stderr}));
  });
}
function builds() {
  const text=cp.execFileSync('powershell.exe',['-NoProfile','-Command',"Get-Process rustc,clippy-driver,link -ErrorAction SilentlyContinue | Select-Object ProcessName,Id | ConvertTo-Json -Compress; exit 0"],{encoding:'utf8',windowsHide:true,stdio:['ignore','pipe','ignore']}).trim();
  return text ? JSON.parse(text) : [];
}
async function one(items,kind,mode,repeat,cohort,frames,capture=false) {
  const name=`${cohort}-${items}-${kind}-${mode}-${repeat}`;
  const destination=path.join(output,name);
  const args=['--items',String(items),'--kind',kind,'--mode',mode,'--warmup','120','--frames',String(frames),'--out',destination];
  if(capture) args.push('--capture');
  let active=builds();
  while(!Array.isArray(active)||active.length){console.log('Waiting for active compiler/linker before '+name);await new Promise(resolve=>setTimeout(resolve,5000));active=builds();}
  const startUtc=new Date().toISOString();
  const result=await run(args);
  const record={name,cohort,repeat,args,startUtc,endUtc:new Date().toISOString(),exitCode:result.code,stderr:result.stderr,compilerProcessesAfter:builds()};
  if(result.code!==0) {manifest.runs.push(record);fs.writeFileSync(path.join(output,'manifest.json'),JSON.stringify(manifest,null,2));throw Error(`${name}: ${result.stderr}`);}
  record.summary=JSON.parse(fs.readFileSync(path.join(destination,'summary.json'),'utf8'));
  record.hashes={};for(const file of fs.readdirSync(destination))record.hashes[file]=sha(path.join(destination,file));
  manifest.runs.push(record);
  fs.writeFileSync(path.join(output,'manifest.json'),JSON.stringify(manifest,null,2));
  console.log(`${name}: p50=${record.summary.wall_ns.p50} ns; mount=${record.summary.mount_wall_ns} ns`);
}
(async()=>{
  const cells=[];for(const items of [100,1000,10000,53000])for(const kind of ['labels','buttons'])for(const mode of ['retained','local'])cells.push([items,kind,mode]);
  for(let repeat=1;repeat<=5;repeat++)for(const cell of repeat%2?cells:[...cells].reverse())await one(...cell,repeat,'primary',10000);
  for(let repeat=1;repeat<=5;repeat++)for(const kind of ['labels','buttons'])await one(100,kind,'rebuild',repeat,'control',1000);
  for(const items of [100,1000,10000,53000])for(const kind of ['labels','buttons'])await one(items,kind,'local',1,'capture',11,true);
  manifest.endUtc=new Date().toISOString();manifest.status='COMPLETE';
  fs.writeFileSync(path.join(output,'manifest.json'),JSON.stringify(manifest,null,2));
  console.log(`COMPLETE ${manifest.runs.length} runs`);
})().catch(error=>{console.error(error);process.exitCode=1});
