const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=process.argv[2];if(!root)throw Error('pass baseline directory');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
const check=(test,message)=>{if(!test)throw Error(message)};
const quantile=(sorted,p)=>sorted[Math.ceil(sorted.length*p/100)-1];
const median=values=>quantile([...values].sort((a,b)=>a-b),50);
check(manifest.status==='COMPLETE'&&manifest.runs.length===98,'incomplete run matrix');
check(manifest.sourceStatus==='','source was dirty');
let previousEnd='',rawCount=0;
for(const run of manifest.runs){
  check(run.startUtc>=previousEnd,`overlapping run ${run.name}`);previousEnd=run.endUtc;
  const folder=path.join(root,run.name),summary=run.summary;
  check(run.exitCode===0&&summary.status==='VALID',`failed ${run.name}`);
  for(const [file,hash] of Object.entries(run.hashes))check(crypto.createHash('sha256').update(fs.readFileSync(path.join(folder,file))).digest('hex')===hash,`hash mismatch ${run.name}/${file}`);
  const samples=fs.readFileSync(path.join(folder,'samples.jsonl'),'utf8').trim().split('\n').map(line=>JSON.parse(line));
  check(samples.length===summary.samples,`sample count ${run.name}`);rawCount+=samples.length;
  const times=[],totals={};
  for(const sample of samples){
    check(Number.isSafeInteger(sample.elapsed_ns)&&sample.elapsed_ns>=0,'invalid duration');times.push(sample.elapsed_ns);
    check(sample.counters.length===10&&new Set(sample.counters.map(c=>c[0])).size===10,'counter schema');
    const c=Object.fromEntries(sample.counters);
    for(const [key,value] of sample.counters){check(Number.isSafeInteger(value)&&value>=0,'invalid counter');totals[key]=(totals[key]||0)+value;}
    if(summary.mode==='Retained')check(c.elements_rebuilt===0&&c.nodes_laid_out===0&&c.nodes_painted===0&&c.frames_produced===0,'idle did work');
    if(summary.mode==='Local')check(c.elements_rebuilt===4&&c.nodes_laid_out===1&&c.nodes_painted<=20&&c.frames_produced===1,'local update lost work or painted body');
    if(summary.mode==='Rebuild')check(c.elements_rebuilt>4&&c.nodes_laid_out>1&&c.nodes_painted>20&&c.frames_produced===1,'positive control did not do full work');
  }
  times.sort((a,b)=>a-b);
  for(const [key,p]of [['p50',50],['p95',95],['p99',99]])check(summary.wall_ns[key]===quantile(times,p),`wrong ${key}`);
  check(summary.wall_ns.min===times[0]&&summary.wall_ns.max===times.at(-1),'wrong extrema');
  for(const[key,value]of Object.entries(totals))check(summary.counter_totals[key]===value,`wrong total ${key}`);
  const clock=JSON.parse(fs.readFileSync(path.join(folder,'clock-samples.json'),'utf8')).sort((a,b)=>a-b);
  check(clock.length===10000&&summary.empty_measurement_wall_ns.p50===quantile(clock,50)&&summary.empty_measurement_wall_ns.p99===quantile(clock,99)&&summary.empty_measurement_wall_ns.min===clock[0],'clock calibration');
}
const cells=[];
for(const items of [100,1000,10000,53000])for(const kind of ['Labels','Buttons'])for(const mode of ['Retained','Local']){
  const runs=manifest.runs.filter(r=>r.cohort==='primary'&&r.summary.items===items&&r.summary.kind===kind&&r.summary.mode===mode);
  check(runs.length===5&&new Set(runs.map(r=>r.repeat)).size===5,'missing repeats');
  const s=runs.map(r=>r.summary),p50=s.map(r=>r.wall_ns.p50),med=median(p50),spread=(Math.max(...p50)-Math.min(...p50))/med;
  cells.push({items,kind,mode,p50_median_ns:med,p50_min_ns:Math.min(...p50),p50_max_ns:Math.max(...p50),p99_min_ns:Math.min(...s.map(r=>r.wall_ns.p99)),p99_max_ns:Math.max(...s.map(r=>r.wall_ns.p99)),mount_median_ns:median(s.map(r=>r.mount_wall_ns)),aa_spread:spread,stability:spread>0.05?'INCONCLUSIVE_FOR_10_PERCENT_CLAIM':'WITHIN_DESCRIPTIVE_AA_LIMIT',render_nodes:s[0].scene.render_nodes,visible:s[0].scene.visible_items_including_partially_clipped,clock_p50_median_ns:median(s.map(r=>r.empty_measurement_wall_ns.p50))});
}
const overlaps=manifest.runs.filter(r=>Array.isArray(r.compilerProcessesAfter)?r.compilerProcessesAfter.length>0:!!r.compilerProcessesAfter).map(r=>r.name);
for(const cell of cells){
  cell.observedCompilerOverlapRuns=manifest.runs.filter(r=>r.cohort==='primary'&&r.summary.items===cell.items&&r.summary.kind===cell.kind&&r.summary.mode===cell.mode&&overlaps.includes(r.name)).map(r=>r.name);
  if(cell.observedCompilerOverlapRuns.length)cell.stability='INCONCLUSIVE_SHARED_HOST_LOAD';
}
const report={source:manifest.source,status:'VERIFIED',rawSamples:rawCount,primarySamples:800000,runs:manifest.runs.length,observedCompilerOverlapRuns:overlaps,cells};
fs.writeFileSync(path.join(root,'analysis.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
